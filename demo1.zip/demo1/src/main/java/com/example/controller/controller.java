package com.example.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.ModelAndView;


import com.example.entity.employee;
import com.example.service.empservice;

@Controller
public class controller {
	
	@Autowired
	private empservice eps;
	
	@GetMapping("/")
	public String Home(Model m)
	{
		List<employee> emp = eps.getallemp();
		m.addAttribute("emp",emp);
		
		return "showtable";
	}
	
	@GetMapping("/inde")
	public String inde()
	{
		return "index";
	}
	
	@PostMapping("/add")
	public ModelAndView add(@ModelAttribute employee e )
	{
		
		eps.addemp(e);
	//	return "redirect:/";
		return new ModelAndView("redirect:/");
	}
	
	@GetMapping("/edit/{id}")
	public ModelAndView edit(@PathVariable int id, Model m)
	{
		employee e =eps.getempbyid(id);
		m.addAttribute("emp",e);
		return new ModelAndView("edit");
	}
	
	@PostMapping("/update")
	public ModelAndView update(@ModelAttribute employee e)
	{
		eps.addemp(e);
		return new ModelAndView("redirect:/");
	}
	
	@GetMapping("/delete/{id}")
	public ModelAndView delete(@PathVariable int id)
	{
		eps.deleteemp(id);
		return new ModelAndView("redirect:/");
	}
	

	
	

}
