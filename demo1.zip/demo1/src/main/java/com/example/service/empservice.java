package com.example.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.entity.employee;
import com.example.repository.empreposi;

@Service
public class empservice {
	
	@Autowired
	private empreposi emr;
	
	public void addemp(employee e)
	{
		emr.save(e);
	}
	
	public List<employee> getallemp()
	{
		return emr.findAll();
	}
	
	public employee getempbyid(int id)
	{
		return emr.findById(id).get();
	}
	
	public void deleteemp(int id)
	{
		emr.deleteById(id);
	}
}
